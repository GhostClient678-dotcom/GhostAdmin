<?php

$servername = "localhost";
$username = "aryanispe_free";
$password = "aryanispe_free";
$dbname = "aryanispe_free";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>